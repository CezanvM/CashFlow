﻿using System.Collections.Generic;
using CashFlow.Controler;
using CashFlow.GameLogic;

namespace CashFlow
{
    public class StorageControler
    {
        public List<Building> BuildingList = new List<Building>();

        }
    }